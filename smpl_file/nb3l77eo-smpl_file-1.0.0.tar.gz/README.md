# Ansible Collection - nb3l77eo.smpl_file

Моя первая ansible collection.


## Included content

- **Modules**:
  - `tchfile_mod`: Модуль создания файла и возможностью его наполнения.

## Supports with ansible-core

- ansible version >= 2.10


## Using this collection

### Installing the Collection file

Для использования коллекции ее необходимо установить:

```bash
ansible-galaxy collection install nb3l77eo-smpl_file-1.0.0.tar.gz
```


## Licensing

GNU General Public License v3.0 or later.

See [LICENSE](https://www.gnu.org/licenses/gpl-3.0.txt) to see the full text.